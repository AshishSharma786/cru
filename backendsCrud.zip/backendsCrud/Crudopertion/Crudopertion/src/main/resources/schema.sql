
create table POJO (
  id number(10) ,
  fname  VARCHAR(30),
  lname  VARCHAR(30),
  primary key(id)
); 

