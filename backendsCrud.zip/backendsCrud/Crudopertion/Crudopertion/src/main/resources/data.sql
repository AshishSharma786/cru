INSERT INTO POJO  VALUES(1,'ROLE','mohan@gmail'); 
INSERT INTO POJO  VALUES(2,'ROL','mohit@gmail'); 
INSERT INTO POJO  VALUES(3,'RO','mon@gmail'); 
INSERT INTO POJO  VALUES(4,'ROLEr','mon@gmail'); 