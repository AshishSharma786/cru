package com.legato.crudopertion.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Pojo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
private Long id;
@Column
private String fname;
@Column
private String lname;

public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}

public String getLname() {
	return lname;
}
public void setLname(String lname) {
	this.lname = lname;
}



public Pojo(String fname, String lname) {
	
	this.fname = fname;
	this.lname=lname;
	
}
public Pojo() {
	
}

}
