package com.legato.crudopertion.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.legato.crudopertion.pojo.Pojo;


	public interface TestRepository  extends JpaRepository<Pojo, Long>{

	}


