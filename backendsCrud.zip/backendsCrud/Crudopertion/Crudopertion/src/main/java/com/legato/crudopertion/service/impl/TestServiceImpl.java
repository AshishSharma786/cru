package com.legato.crudopertion.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.legato.crudopertion.pojo.Pojo;
import com.legato.crudopertion.repositories.TestRepository;
import com.legato.crudopertion.service.TestService;

@Service
public class TestServiceImpl implements TestService{

	@Autowired
	TestRepository testRepository;
	@Override
	public List<Pojo> getUsers() {
		
		return testRepository.findAll();
	}
	@Override
	public Optional<Pojo>  getUser(Long id) {
		// TODO Auto-generated method stub
		return testRepository.findById(id);
	}
	@Override
	public Pojo createUser(Pojo pojo) {
		// TODO Auto-generated method stub
		return testRepository.save(pojo);
	}
	@Override
	public Boolean deleteUser(Long id) {
		// TODO Auto-generated method stub
		testRepository.deleteById(id);
		return  true;
	}
	@Override
	public Pojo updateUser(Pojo pojo) {
		// TODO Auto-generated method stub
		return testRepository.save(pojo);
	}
	
	







}
 