package com.legato.crudopertion.service;

import java.util.List;
import java.util.Optional;

import com.legato.crudopertion.pojo.Pojo;




public interface TestService {
	public List<Pojo>  getUsers();
	public Optional<Pojo> getUser(Long id);
	public Pojo createUser(Pojo pojo);
	public Boolean  deleteUser(Long id);
	public Pojo updateUser(Pojo pojo);

}
